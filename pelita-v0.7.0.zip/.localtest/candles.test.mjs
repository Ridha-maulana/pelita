// scripts/vitest-shim.ts
import { describe as d, it as i } from "node:test";
import assert from "node:assert/strict";
var describe = d;
var it = i;
var close = (a, b, digits = 2) => Math.abs(a - b) < Math.pow(10, -digits) / 2;
function expect(actual) {
  const mk2 = (neg) => {
    const chk = (ok, msg) => {
      if (neg ? ok : !ok) assert.fail((neg ? "NOT " : "") + msg);
    };
    return {
      toBe: (e) => chk(Object.is(actual, e), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(e)}`),
      toEqual: (e) => {
        try {
          assert.deepStrictEqual(actual, e);
          chk(true, "");
        } catch (err) {
          if (neg) return;
          throw err;
        }
        if (neg) assert.fail("expected not equal");
      },
      toBeCloseTo: (e, dg = 2) => chk(close(actual, e, dg), `expected ${actual} close to ${e}`),
      toBeTruthy: () => chk(!!actual, `expected truthy, got ${actual}`),
      toBeFalsy: () => chk(!actual, `expected falsy, got ${actual}`),
      toBeNull: () => chk(actual === null, `expected null, got ${actual}`),
      toBeGreaterThan: (e) => chk(actual > e, `expected ${actual} > ${e}`),
      toBeLessThan: (e) => chk(actual < e, `expected ${actual} < ${e}`),
      toHaveLength: (n2) => chk(actual.length === n2, `expected length ${n2}, got ${actual.length}`),
      toContain: (e) => chk(actual.includes(e), `expected ${JSON.stringify(actual)} to contain ${e}`),
      toThrow: () => {
        let t = false;
        try {
          actual();
        } catch {
          t = true;
        }
        chk(t, "expected throw");
      }
    };
  };
  return { ...mk2(false), not: mk2(true) };
}

// src/domain/time.ts
var WIB_OFFSET_MIN = 7 * 60;
var MS_MIN = 6e4;
var p2 = (n2) => String(n2).padStart(2, "0");
function toMs(v) {
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v;
  const s = v.trim();
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(s)) {
    const ms = Date.parse(s);
    if (!Number.isNaN(ms)) return ms;
  }
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return Number.NaN;
  const [, y, mo, d2, h = "0", mi = "0", se = "0"] = m;
  return Date.UTC(+y, +mo - 1, +d2, +h, +mi, +se) - WIB_OFFSET_MIN * MS_MIN;
}
function wibParts(v) {
  const shifted = new Date(toMs(v) + WIB_OFFSET_MIN * MS_MIN);
  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  return {
    year,
    month,
    day,
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
    dayKey: `${year}-${p2(month)}-${p2(day)}`,
    monthKey: `${year}-${p2(month)}`
  };
}
function tradingDayKey(v) {
  return wibParts(toMs(v) - 7 * 60 * MS_MIN).dayKey;
}
var SESSIONS = [
  { name: "Asia", label: "Asia", hours: "07:00\u201314:00", test: (h) => h >= 7 && h < 14 },
  { name: "London", label: "London", hours: "14:00\u201320:00", test: (h) => h >= 14 && h < 20 },
  { name: "New York", label: "New York", hours: "20:00\u201304:00", test: (h) => h >= 20 || h < 4 },
  { name: "Overlap", label: "Overlap", hours: "04:00\u201307:00", test: (h) => h >= 4 && h < 7 }
];
function sessionOfHour(hour) {
  return (SESSIONS.find((s) => s.test(hour)) ?? SESSIONS[3]).name;
}
var sessionOf = (v) => sessionOfHour(wibParts(v).hour);
function sessionOf3(v) {
  const s = sessionOf(v);
  return s === "Overlap" ? "New York" : s;
}
function weekStartKey(dayKey) {
  const ms = Date.UTC(+dayKey.slice(0, 4), +dayKey.slice(5, 7) - 1, +dayKey.slice(8, 10));
  const wd = (new Date(ms).getUTCDay() + 6) % 7;
  const d2 = new Date(ms - wd * 864e5);
  return `${d2.getUTCFullYear()}-${p2(d2.getUTCMonth() + 1)}-${p2(d2.getUTCDate())}`;
}
var addDaysKey = (dayKey, n2) => {
  const ms = Date.UTC(+dayKey.slice(0, 4), +dayKey.slice(5, 7) - 1, +dayKey.slice(8, 10)) + n2 * 864e5;
  const d2 = new Date(ms);
  return `${d2.getUTCFullYear()}-${p2(d2.getUTCMonth() + 1)}-${p2(d2.getUTCDate())}`;
};
var daysInMonth = (year, month1) => new Date(Date.UTC(year, month1, 0)).getUTCDate();
var mondayOffset = (year, month1) => (new Date(Date.UTC(year, month1 - 1, 1)).getUTCDay() + 6) % 7;

// src/domain/trading.ts
var CONTRACT_SIZES = {
  XAUUSD: 100,
  GOLD: 100,
  EURUSD: 1e5,
  GBPUSD: 1e5,
  USDJPY: 1e5,
  GBPJPY: 1e5,
  AUDUSD: 1e5,
  USDCAD: 1e5,
  USDCHF: 1e5,
  NAS100: 1,
  BTCUSD: 1
};
var SYMBOLS = Object.keys(CONTRACT_SIZES);
var contractSize = (symbol) => CONTRACT_SIZES[symbol] ?? 1e5;
var num = (v) => v === null || v === void 0 || v === "" ? NaN : Number(v);
var hasNum = (v) => Number.isFinite(num(v));
function pnlFor(t, exit) {
  if (!hasNum(exit)) return 0;
  const diff = t.side === "Long" ? exit - t.entry : t.entry - exit;
  return diff * t.lots * contractSize(t.symbol) - (Number(t.fees) || 0);
}
function pipSizeOf(symbol) {
  const u = String(symbol || "").toUpperCase();
  if (u.includes("XAU") || u === "GOLD") return 0.1;
  if (u.includes("XAG")) return 0.01;
  if (u.includes("JPY")) return 0.01;
  if (/BTC|ETH|NAS|US30|SPX/.test(u)) return 1;
  return 1e-4;
}
function pipsOf(t) {
  if (t.status !== "closed" || !hasNum(t.exit)) return 0;
  const d2 = t.side === "Long" ? t.exit - t.entry : t.entry - t.exit;
  return d2 / pipSizeOf(t.symbol);
}

// src/domain/period.ts
var tradeDate = (t) => t.closedAt ?? t.openedAt;

// src/domain/format.ts
var MONTHS_ID = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];

// src/domain/candles.ts
var SES_LABEL = { Asia: "Asia", London: "London", "New York": "New York" };
var SES_SHORT = { Asia: "AS", London: "LDN", "New York": "NY" };
var dayLabel = (day) => `${day.slice(8, 10)} ${MONTHS_ID[Number(day.slice(5, 7)) - 1]}`;
var p22 = (n2) => String(n2).padStart(2, "0");
function buildCandles(trades, tf) {
  const sorted = trades.filter((t) => t.status === "closed" && !t.deletedAt).sort((a, b) => Date.parse(tradeDate(a)) - Date.parse(tradeDate(b)) || a.id.localeCompare(b.id));
  const out = [];
  let eq = 0, pq = 0;
  let cur = null;
  for (const t of sorted) {
    const d2 = tradeDate(t);
    const w = wibParts(d2);
    const tday = tradingDayKey(d2);
    const hh = p22(w.hour);
    let k, label, short;
    if (tf === "H1") {
      k = `${w.dayKey} ${hh}`;
      label = `${dayLabel(w.dayKey)} ${hh}:00`;
      short = `${w.dayKey.slice(8, 10)}/${w.dayKey.slice(5, 7)} ${hh}`;
    } else if (tf === "SES") {
      const s = sessionOf3(d2);
      k = `${tday}|${s}`;
      label = `${dayLabel(tday)} \xB7 ${SES_LABEL[s]}`;
      short = `${tday.slice(8, 10)}/${tday.slice(5, 7)} ${SES_SHORT[s]}`;
    } else if (tf === "W1") {
      const mon = weekStartKey(tday);
      k = mon;
      label = `Minggu ${dayLabel(mon)} \u2013 ${dayLabel(addDaysKey(mon, 4))}`;
      short = dayLabel(mon);
    } else if (tf === "M1") {
      k = w.monthKey;
      label = `${MONTHS_ID[w.month - 1]} ${w.year}`;
      short = MONTHS_ID[w.month - 1];
    } else if (tf === "Y1") {
      k = String(w.year);
      label = `Tahun ${w.year}`;
      short = String(w.year);
    } else {
      k = tday;
      label = dayLabel(tday);
      short = dayLabel(tday);
    }
    const before = eq, after = eq + (Number(t.pnl) || 0);
    const pb = pq, pa = pq + pipsOf(t);
    eq = after;
    pq = pa;
    if (cur && cur.k === k) {
      cur.c = after;
      cur.h = Math.max(cur.h, before, after);
      cur.l = Math.min(cur.l, before, after);
      cur.n++;
      cur.pc = pa;
      cur.ids.push(t.id);
    } else {
      cur = { k, label, short, o: before, c: after, h: Math.max(before, after), l: Math.min(before, after), n: 1, po: pb, pc: pa, ids: [t.id] };
      out.push(cur);
    }
  }
  return out;
}
function candleNum(v) {
  const a = Math.abs(v);
  const s = a >= 1e4 ? (a / 1e3).toFixed(1) + "k" : a >= 1e3 ? (a / 1e3).toFixed(2) + "k" : a >= 100 ? a.toFixed(0) : a.toFixed(2);
  return (v < 0 ? "-" : v > 0 ? "+" : "") + s;
}

// src/domain/drilldown.ts
var DD_DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat"];
var DD_WEEKEND = "Akhir pekan (Sab\u2013Min)";
function ddBuild(trades) {
  const out = [];
  for (const t of trades) {
    if (t.status !== "closed" || t.deletedAt) continue;
    const w = wibParts(tradeDate(t));
    const off = mondayOffset(w.year, w.month);
    const di = Math.min((w.weekday + 6) % 7, 5);
    out.push({ mk: w.monthKey, iso: w.dayKey, wk: Math.floor((w.day - 1 + off) / 7) + 1, di, day: di < 5 ? DD_DAYS[di] : DD_WEEKEND, ses: sessionOfHour(w.hour), pnl: Number(t.pnl) || 0, pips: pipsOf(t) });
  }
  return out;
}
function ddStat(rs) {
  const w = rs.filter((r) => r.pnl > 0), l = rs.filter((r) => r.pnl < 0);
  const sum = (a, k = "pnl") => a.reduce((x, r) => x + r[k], 0);
  return {
    n: rs.length,
    wins: w.length,
    losses: l.length,
    wr: rs.length ? w.length / rs.length * 100 : 0,
    profit: sum(rs),
    pips: sum(rs, "pips"),
    avgWin: w.length ? sum(w) / w.length : 0,
    avgLoss: l.length ? sum(l) / l.length : 0,
    days: new Set(rs.map((r) => r.iso)).size,
    weeks: new Set(rs.map((r) => r.mk + r.wk)).size,
    sessions: new Set(rs.map((r) => r.ses)).size
  };
}
var ym = (mk2) => ({ y: Number(mk2.slice(0, 4)), m: Number(mk2.slice(5, 7)) });
var weeksIn = (mk2) => {
  const { y, m } = ym(mk2);
  return Math.floor((daysInMonth(y, m) - 1 + mondayOffset(y, m)) / 7) + 1;
};
function wkRange(mk2, wk) {
  const { y, m } = ym(mk2);
  const dim = daysInMonth(y, m), off = mondayOffset(y, m);
  const a = Math.max(1, (wk - 1) * 7 - off + 1), b = Math.min(dim, (wk - 1) * 7 - off + 7);
  return a === b ? `${a} ${MONTHS_ID[m - 1]}` : `${a}\u2013${b} ${MONTHS_ID[m - 1]}`;
}

// tests/unit/fixtures.ts
var n = 0;
function mk(o) {
  const t = {
    id: `t${++n}`,
    symbol: "XAUUSD",
    side: "Long",
    closedAt: null,
    entry: 2700,
    lots: 0.1,
    sl: null,
    tp: null,
    fees: 0,
    pnl: 0,
    status: o.exit === null ? "open" : "closed",
    exitMethod: "",
    setup: "",
    review: "",
    attachmentIds: [],
    updatedAt: "2026-10-01T00:00:00+07:00",
    ...o
  };
  if (t.status === "closed") {
    t.closedAt = t.closedAt ?? t.openedAt;
    t.pnl = o.pnl ?? pnlFor(t, t.exit);
  }
  return t;
}

// tests/unit/candles.test.ts
var T = (iso, pnl) => mk({ openedAt: iso, closedAt: iso, exit: 1, pnl });
describe("kandel", () => {
  it("menggabungkan OHLC dalam satu kandel jam", () => {
    const c = buildCandles([T("2026-10-20T09:05:00+07:00", 10), T("2026-10-20T09:20:00+07:00", -30), T("2026-10-20T09:40:00+07:00", 5)], "H1");
    expect(c).toHaveLength(1);
    expect([c[0].o, c[0].h, c[0].l, c[0].c, c[0].n]).toEqual([0, 10, -20, -15, 3]);
  });
  it("kandel berikutnya dibuka di penutupan sebelumnya", () => {
    const c = buildCandles([T("2026-10-20T09:05:00+07:00", 10), T("2026-10-20T11:00:00+07:00", 20)], "H1");
    expect(c).toHaveLength(2);
    expect(c[1].o).toBe(10);
    expect(c[1].c).toBe(30);
  });
  it("hari trading mulai 07:00 WIB: 06:30 ikut hari sebelumnya", () => {
    const c = buildCandles([T("2026-10-20T20:00:00+07:00", 5), T("2026-10-21T06:30:00+07:00", 5), T("2026-10-21T07:10:00+07:00", 5)], "D1");
    expect(c.map((x) => x.n)).toEqual([2, 1]);
    expect(c[0].k).toBe("2026-10-20");
  });
  it("sesi: Overlap (04\u201307) digabung ke New York", () => {
    const c = buildCandles([T("2026-10-20T21:00:00+07:00", 5), T("2026-10-21T05:00:00+07:00", 5)], "SES");
    expect(c).toHaveLength(1);
    expect(c[0].label).toContain("New York");
  });
  it("minggu mulai Senin; bulan dan tahun mengikuti tanggal kalender", () => {
    const w = buildCandles([T("2026-10-19T10:00:00+07:00", 1), T("2026-10-23T10:00:00+07:00", 1), T("2026-10-26T10:00:00+07:00", 1)], "W1");
    expect(w.map((x) => x.n)).toEqual([2, 1]);
    const m = buildCandles([T("2026-10-31T23:00:00+07:00", 1), T("2026-11-01T01:00:00+07:00", 1)], "M1");
    expect(m.map((x) => x.k)).toEqual(["2026-10", "2026-11"]);
    expect(buildCandles([T("2025-12-31T10:00:00+07:00", 1), T("2026-01-01T10:00:00+07:00", 1)], "Y1")).toHaveLength(2);
  });
  it("abaikan trade open dan terhapus; urutan input tidak berpengaruh", () => {
    const open = mk({ openedAt: "2026-10-20T09:00:00+07:00", exit: null });
    const del = { ...T("2026-10-20T09:10:00+07:00", 50), deletedAt: "2026-10-21T00:00:00+07:00" };
    const c = buildCandles([T("2026-10-20T11:00:00+07:00", 20), open, del, T("2026-10-20T09:05:00+07:00", 10)], "H1");
    expect(c.map((x) => x.c)).toEqual([10, 30]);
  });
  it("tanpa trade \u2192 kosong; angka ringkas", () => {
    expect(buildCandles([], "D1")).toEqual([]);
    expect(candleNum(1250)).toBe("+1.25k");
    expect(candleNum(-12.5)).toBe("-12.50");
    expect(candleNum(0)).toBe("0.00");
  });
});
describe("drill-down", () => {
  it("minggu dalam bulan: minggu 1 berisi tanggal 1 (kalender mulai Senin)", () => {
    expect(weeksIn("2026-10")).toBe(5);
    expect(wkRange("2026-10", 1)).toBe("1\u20134 Okt");
    expect(wkRange("2026-10", 2)).toBe("5\u201311 Okt");
    expect(wkRange("2026-10", 5)).toBe("26\u201331 Okt");
  });
  it("rekaman: hari, minggu, sesi, akhir pekan digabung", () => {
    const r = ddBuild([T("2026-10-20T15:00:00+07:00", 10), T("2026-10-24T10:00:00+07:00", -5), T("2026-10-25T10:00:00+07:00", -5)]);
    expect(r[0].day).toBe("Selasa");
    expect(r[0].ses).toBe("London");
    expect(r[0].wk).toBe(4);
    expect(r[1].di).toBe(5);
    expect(r[2].di).toBe(5);
  });
  it("statistik: win rate, rata-rata, jumlah hari", () => {
    const s = ddStat(ddBuild([T("2026-10-20T15:00:00+07:00", 30), T("2026-10-20T16:00:00+07:00", -10), T("2026-10-21T16:00:00+07:00", 10)]));
    expect(s.n).toBe(3);
    expect(s.wins).toBe(2);
    expect(s.wr).toBeCloseTo(66.67, 1);
    expect(s.profit).toBe(30);
    expect(s.avgWin).toBe(20);
    expect(s.avgLoss).toBe(-10);
    expect(s.days).toBe(2);
    expect(s.weeks).toBe(1);
  });
});
