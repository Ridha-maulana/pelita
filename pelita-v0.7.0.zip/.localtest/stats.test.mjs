// scripts/vitest-shim.ts
import { describe as d, it as i } from "node:test";
import assert from "node:assert/strict";
var describe = d;
var it = i;
var close = (a, b, digits = 2) => Math.abs(a - b) < Math.pow(10, -digits) / 2;
function expect(actual) {
  const mk2 = (neg) => {
    const chk = (ok, msg) => {
      if (neg ? ok : !ok) assert.fail((neg ? "NOT " : "") + msg);
    };
    return {
      toBe: (e) => chk(Object.is(actual, e), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(e)}`),
      toEqual: (e) => {
        try {
          assert.deepStrictEqual(actual, e);
          chk(true, "");
        } catch (err) {
          if (neg) return;
          throw err;
        }
        if (neg) assert.fail("expected not equal");
      },
      toBeCloseTo: (e, dg = 2) => chk(close(actual, e, dg), `expected ${actual} close to ${e}`),
      toBeTruthy: () => chk(!!actual, `expected truthy, got ${actual}`),
      toBeFalsy: () => chk(!actual, `expected falsy, got ${actual}`),
      toBeNull: () => chk(actual === null, `expected null, got ${actual}`),
      toBeGreaterThan: (e) => chk(actual > e, `expected ${actual} > ${e}`),
      toBeLessThan: (e) => chk(actual < e, `expected ${actual} < ${e}`),
      toHaveLength: (n2) => chk(actual.length === n2, `expected length ${n2}, got ${actual.length}`),
      toContain: (e) => chk(actual.includes(e), `expected ${JSON.stringify(actual)} to contain ${e}`),
      toThrow: () => {
        let t = false;
        try {
          actual();
        } catch {
          t = true;
        }
        chk(t, "expected throw");
      }
    };
  };
  return { ...mk2(false), not: mk2(true) };
}

// src/domain/trading.ts
var CONTRACT_SIZES = {
  XAUUSD: 100,
  GOLD: 100,
  EURUSD: 1e5,
  GBPUSD: 1e5,
  USDJPY: 1e5,
  GBPJPY: 1e5,
  AUDUSD: 1e5,
  USDCAD: 1e5,
  USDCHF: 1e5,
  NAS100: 1,
  BTCUSD: 1
};
var SYMBOLS = Object.keys(CONTRACT_SIZES);
var contractSize = (symbol) => CONTRACT_SIZES[symbol] ?? 1e5;
var num = (v) => v === null || v === void 0 || v === "" ? NaN : Number(v);
var hasNum = (v) => Number.isFinite(num(v));
function pnlFor(t, exit) {
  if (!hasNum(exit)) return 0;
  const diff = t.side === "Long" ? exit - t.entry : t.entry - exit;
  return diff * t.lots * contractSize(t.symbol) - (Number(t.fees) || 0);
}
var riskFor = (entry, sl, lots, symbol) => entry && hasNum(sl) && sl !== 0 && lots ? Math.abs(entry - sl) * lots * contractSize(symbol) : 0;
var rewardFor = (entry, tp, lots, symbol) => entry && hasNum(tp) && tp !== 0 && lots ? Math.abs(tp - entry) * lots * contractSize(symbol) : 0;
function pipSizeOf(symbol) {
  const u = String(symbol || "").toUpperCase();
  if (u.includes("XAU") || u === "GOLD") return 0.1;
  if (u.includes("XAG")) return 0.01;
  if (u.includes("JPY")) return 0.01;
  if (/BTC|ETH|NAS|US30|SPX/.test(u)) return 1;
  return 1e-4;
}
function pipsOf(t) {
  if (t.status !== "closed" || !hasNum(t.exit)) return 0;
  const d2 = t.side === "Long" ? t.exit - t.entry : t.entry - t.exit;
  return d2 / pipSizeOf(t.symbol);
}
var isClosed = (t) => t.status === "closed" && !t.deletedAt;

// src/domain/account.ts
var sum = (a) => a.reduce((x, y) => x + y, 0);
function capitalSums(account2) {
  const cap = account2.capital ?? [];
  const deposits = sum(cap.filter((c) => c.type !== "withdraw").map((c) => Number(c.amount) || 0));
  const withdrawals = sum(cap.filter((c) => c.type === "withdraw").map((c) => Number(c.amount) || 0));
  return { deposits, withdrawals };
}
function startingBalance(account2) {
  const { deposits, withdrawals } = capitalSums(account2);
  return Math.max((Number(account2.balance) || 0) - deposits + withdrawals, 1);
}
function currentBalance(account2) {
  return (Number(account2.balance) || 0) + sum(account2.trades.filter(isClosed).map((t) => Number(t.pnl) || 0));
}

// src/domain/time.ts
var WIB_OFFSET_MIN = 7 * 60;
var MS_MIN = 6e4;
var p2 = (n2) => String(n2).padStart(2, "0");
function toMs(v) {
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v;
  const s = v.trim();
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(s)) {
    const ms = Date.parse(s);
    if (!Number.isNaN(ms)) return ms;
  }
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return Number.NaN;
  const [, y, mo, d2, h = "0", mi = "0", se = "0"] = m;
  return Date.UTC(+y, +mo - 1, +d2, +h, +mi, +se) - WIB_OFFSET_MIN * MS_MIN;
}
function wibParts(v) {
  const shifted = new Date(toMs(v) + WIB_OFFSET_MIN * MS_MIN);
  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  return {
    year,
    month,
    day,
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
    dayKey: `${year}-${p2(month)}-${p2(day)}`,
    monthKey: `${year}-${p2(month)}`
  };
}
var dayKeyOf = (v) => wibParts(v).dayKey;
var monthKeyOf = (v) => wibParts(v).monthKey;
function holdMinutes(openedAt, closedAt) {
  if (!closedAt) return null;
  const d2 = (toMs(closedAt) - toMs(openedAt)) / MS_MIN;
  return Number.isFinite(d2) && d2 >= 0 ? d2 : null;
}

// src/domain/period.ts
var tradeDate = (t) => t.closedAt ?? t.openedAt;
function inPeriod(t, o) {
  const d2 = tradeDate(t);
  const key = dayKeyOf(d2);
  const now = wibParts(o.now ?? Date.now());
  switch (o.period) {
    case "All time":
      return true;
    case "Year-to-date":
      return wibParts(d2).year === now.year;
    case "Monthly":
      return wibParts(d2).monthKey === now.monthKey;
    case "Weekly":
      return toMs(d2) >= (o.now ?? Date.now()) - 7 * 864e5;
    case "Custom date range":
      if (o.start && key < o.start) return false;
      if (o.end && key > o.end) return false;
      return true;
  }
}

// src/domain/stats.ts
var sum2 = (a) => a.reduce((x, y) => x + y, 0);
var avg = (a) => a.length ? sum2(a) / a.length : 0;
var byCloseTime = (a) => a.slice().sort((x, y) => toMs(tradeDate(x)) - toMs(tradeDate(y)));
function computeStats(account2, filtered) {
  const cl = byCloseTime(filtered.filter(isClosed));
  const n2 = cl.length;
  const wins = cl.filter((t) => t.pnl > 0);
  const losses = cl.filter((t) => t.pnl < 0);
  const grossWin = sum2(wins.map((t) => t.pnl));
  const grossLoss = Math.abs(sum2(losses.map((t) => t.pnl)));
  const total = sum2(cl.map((t) => Number(t.pnl) || 0));
  const profitFactor = grossLoss ? grossWin / grossLoss : grossWin ? Infinity : 0;
  const dayPnl = {};
  const monthPnl = {};
  for (const t of cl) {
    const d2 = dayKeyOf(tradeDate(t));
    dayPnl[d2] = (dayPnl[d2] ?? 0) + (Number(t.pnl) || 0);
    const m = monthKeyOf(tradeDate(t));
    monthPnl[m] = (monthPnl[m] ?? 0) + (Number(t.pnl) || 0);
  }
  const dayKeys = Object.keys(dayPnl).sort();
  let eq = 0, peak = 0, maxDd = 0;
  for (const t of cl) {
    eq += Number(t.pnl) || 0;
    peak = Math.max(peak, eq);
    maxDd = Math.max(maxDd, peak - eq);
  }
  const cumByDay = [], ddByDay = [];
  let c = 0, pk = 0;
  for (const k of dayKeys) {
    c += dayPnl[k];
    pk = Math.max(pk, c);
    cumByDay.push(c);
    ddByDay.push(c - pk);
  }
  const rrs = cl.map((t) => {
    const r = riskFor(t.entry, t.sl, t.lots, t.symbol), w = rewardFor(t.entry, t.tp, t.lots, t.symbol);
    return r && w ? w / r : null;
  }).filter((v) => v !== null);
  const rs = cl.map((t) => {
    const r = riskFor(t.entry, t.sl, t.lots, t.symbol);
    return r ? (Number(t.pnl) || 0) / r : null;
  }).filter((v) => v !== null);
  const avgLossAbs = losses.length ? grossLoss / losses.length : 0;
  const expectancyR = rs.length ? avg(rs) : avgLossAbs && n2 ? total / n2 / avgLossAbs : 0;
  let ws = 0, ls = 0, mw = 0, ml = 0;
  for (const t of cl) {
    if (t.pnl > 0) {
      ws++;
      ls = 0;
      mw = Math.max(mw, ws);
    } else if (t.pnl < 0) {
      ls++;
      ws = 0;
      ml = Math.max(ml, ls);
    } else {
      ws = 0;
      ls = 0;
    }
  }
  const pips = cl.map(pipsOf);
  const holds = cl.map((t) => holdMinutes(t.openedAt, t.closedAt)).filter((v) => v !== null);
  const bestDayKey = dayKeys.length ? dayKeys.reduce((a, b) => dayPnl[b] > dayPnl[a] ? b : a) : null;
  const { deposits, withdrawals } = capitalSums(account2);
  return {
    n: n2,
    wins,
    losses,
    grossWin,
    grossLoss,
    winRate: n2 ? wins.length / n2 * 100 : 0,
    profitFactor,
    total,
    avgWin: wins.length ? grossWin / wins.length : 0,
    avgLoss: losses.length ? -avgLossAbs : 0,
    avgRR: rrs.length ? avg(rrs) : null,
    expectancyR,
    recoveryFactor: maxDd ? total / maxDd : total > 0 ? Infinity : 0,
    maxDrawdown: maxDd,
    highWater: peak,
    longs: cl.filter((t) => t.side === "Long"),
    shorts: cl.filter((t) => t.side === "Short"),
    dayPnl,
    dayKeys,
    monthPnl,
    bestDayKey,
    maxWinStreak: mw,
    maxLossStreak: ml,
    pips,
    totalPips: sum2(pips),
    tpPips: wins.map(pipsOf),
    slPips: losses.map((t) => Math.abs(pipsOf(t))),
    holds,
    avgHold: avg(holds),
    cumByDay,
    ddByDay,
    start: startingBalance(account2),
    balance: Number(account2.balance) || 0,
    deposits,
    withdrawals
  };
}
var tradingStyle = (avgHoldMin) => avgHoldMin <= 0 ? "" : avgHoldMin < 60 ? "Scalping" : avgHoldMin < 1440 ? "Day trading" : avgHoldMin < 10080 ? "Swing" : "Position";

// src/domain/format.ts
function money(n2, currency = "USD") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(Number(n2) || 0);
}
var tone = (n2) => n2 > 0 ? "pos" : n2 < 0 ? "neg" : "";
function fmtHold(min) {
  if (!Number.isFinite(min) || min <= 0) return "\u2014";
  if (min < 60) return `${Math.round(min)} mnt`;
  if (min < 1440) {
    const h2 = Math.floor(min / 60), m = Math.round(min % 60);
    return m ? `${h2} j ${m} mnt` : `${h2} j`;
  }
  const d2 = Math.floor(min / 1440), h = Math.round(min % 1440 / 60);
  return h ? `${d2} hr ${h} j` : `${d2} hr`;
}
var MONTHS_ID = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];

// src/domain/advanced.ts
var sgn = (n2, d2 = 1) => `${n2 > 0 ? "+" : ""}${n2.toFixed(d2)}`;
var wrOf = (a) => a.length ? Math.round(a.filter((t) => t.pnl > 0).length / a.length * 100) : 0;
var avg2 = (a) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
var mx = (a) => a.length ? Math.max(...a) : 0;
function advancedRows(account2, s, view) {
  const cur = account2.currency;
  const fm = (n3) => money(n3, cur);
  const sg = (n3) => `${n3 > 0 ? "+" : ""}${fm(n3)}`;
  const n2 = s.n;
  const base = s.balance || 1;
  const vk = `${view.y}-${String(view.m + 1).padStart(2, "0")}`;
  const inM = [...s.wins, ...s.losses].filter((t) => monthKeyOf(tradeDate(t)) === vk);
  const mPnl = inM.reduce((a, t) => a + (Number(t.pnl) || 0), 0);
  const mPips = inM.reduce((a, t) => a + pipsOf(t), 0);
  const days = s.dayKeys.length;
  const best = s.bestDayKey ? s.dayPnl[s.bestDayKey] : 0;
  const mon = MONTHS_ID[view.m];
  const pf = s.profitFactor, rf = s.recoveryFactor;
  return [
    ["Total Trades", String(n2), ""],
    ["Profit Factor", pf === Infinity ? "\u221E" : pf.toFixed(2), n2 ? pf >= 1 ? "pos" : "neg" : ""],
    ["Avg. R:R", s.avgRR ? s.avgRR.toFixed(1) : "\u2014", ""],
    ["Expectancy", `${sgn(s.expectancyR, 2)}R \xB7 ${sg(n2 ? s.total / n2 : 0)}`, tone(s.expectancyR)],
    ["Recovery Factor", rf === Infinity ? "\u221E" : rf.toFixed(1), n2 ? rf >= 1 ? "pos" : "neg" : ""],
    ["Avg. Win / Loss", `${sg(s.avgWin)} / ${sg(s.avgLoss)}`, ""],
    ["Gross Profit", sg(s.grossWin), s.grossWin ? "pos" : ""],
    ["Gross Loss", s.grossLoss ? `-${fm(s.grossLoss)}` : fm(0), s.grossLoss ? "neg" : ""],
    ["Longs Won", `${wrOf(s.longs)}% (${s.longs.length})`, ""],
    ["Shorts Won", `${wrOf(s.shorts)}% (${s.shorts.length})`, ""],
    ["Best Day", s.bestDayKey ? `${sg(best)} \xB7 ${sgn(best / base * 100, 2)}%` : "\u2014", s.bestDayKey ? tone(best) : ""],
    ["Avg Daily Gain", days ? `${sg(s.total / days)} \xB7 ${sgn(s.total / days / base * 100, 2)}%` : "\u2014", days ? tone(s.total) : ""],
    ["Max Win Streak", `${s.maxWinStreak}\xD7`, s.maxWinStreak ? "pos" : ""],
    ["Max Loss Streak", `${s.maxLossStreak}\xD7`, s.maxLossStreak ? "neg" : ""],
    ["Avg Hold", s.holds.length ? `${fmtHold(s.avgHold)} \xB7 ${tradingStyle(s.avgHold)}` : "\u2014", ""],
    ["Perolehan Pips", `${sgn(s.totalPips)} pips`, tone(s.totalPips)],
    [`Profit Pips ${mon}`, `${sgn(mPips)} pips`, tone(mPips)],
    ["Average TP Pips", `${avg2(s.tpPips).toFixed(1)} pips`, s.tpPips.length ? "pos" : ""],
    ["Average SL Pips", `${avg2(s.slPips).toFixed(1)} pips`, s.slPips.length ? "neg" : ""],
    ["Max TP Pips", `${mx(s.tpPips).toFixed(1)} pips`, s.tpPips.length ? "pos" : ""],
    ["Max SL Pips", `${mx(s.slPips).toFixed(1)} pips`, s.slPips.length ? "neg" : ""],
    ["Profit", sg(s.total), tone(s.total)],
    ["Gain", `${sgn(s.total / s.start * 100, 2)}%`, tone(s.total)],
    ["Abs. Gain", `${sgn(s.total / (s.start + s.deposits) * 100, 2)}%`, tone(s.total)],
    [`Gain ${mon}`, `${sgn(mPnl / s.start * 100, 2)}% \xB7 ${sg(mPnl)}`, tone(mPnl)],
    ["Max Drawdown", s.maxDrawdown ? `-${fm(s.maxDrawdown)} \xB7 -${(s.maxDrawdown / base * 100).toFixed(2)}%` : fm(0), s.maxDrawdown ? "neg" : ""],
    ["High Water Mark", `${s.highWater > 0 ? "+" : ""}${fm(s.highWater)}`, s.highWater > 0 ? "pos" : ""],
    ["Balance", fm(s.balance), ""],
    ["Equity", fm(s.balance + s.total), tone(s.total)],
    ["Deposits", fm(s.deposits), s.deposits ? "pos" : ""],
    ["Withdrawals", fm(s.withdrawals), s.withdrawals ? "neg" : ""]
  ];
}

// src/domain/dna.ts
var clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
var gradeOf = (v) => v >= 85 ? "A" : v >= 70 ? "B" : v >= 55 ? "C" : v >= 40 ? "D" : "E";
var bandOf = (v) => v >= 75 ? 0 : v >= 50 ? 1 : 2;
function computeDna(s, sorted) {
  const n2 = sorted.length;
  const mKeys = Object.keys(s.monthPnl);
  const mWin = mKeys.filter((k) => s.monthPnl[k] > 0).length;
  const dWin = s.dayKeys.filter((k) => s.dayPnl[k] > 0).length;
  const dd = s.maxDrawdown / Math.max(s.balance, 1) * 100;
  const rf = s.maxDrawdown ? s.total / s.maxDrawdown : s.total > 0 ? 3 : 0;
  const pf = s.profitFactor === Infinity ? 3 : s.profitFactor;
  const slPct = n2 ? sorted.filter((t) => t.sl !== null && t.sl !== void 0).length / n2 * 100 : 0;
  const lots = sorted.map((t) => Number(t.lots) || 0);
  const mean = lots.length ? lots.reduce((a, b) => a + b, 0) / lots.length : 0;
  const cv = mean ? Math.sqrt(lots.reduce((a, b) => a + (b - mean) ** 2, 0) / lots.length) / mean : 0;
  let mart = 0;
  sorted.forEach((t, i2) => {
    if (i2 > 0 && sorted[i2 - 1].pnl < 0 && (Number(t.lots) || 0) > (Number(sorted[i2 - 1].lots) || 0) * 1.5) mart++;
  });
  const martFlag = mart >= 2;
  const maxStreak = s.maxLossStreak;
  const sKons = Math.round((mKeys.length ? mWin / mKeys.length * 100 : 0) * 0.5 + (s.dayKeys.length ? dWin / s.dayKeys.length * 100 : 0) * 0.5);
  const sProf = Math.round(clamp((pf - 0.5) / 2) * 100 * 0.6 + clamp((s.expectancyR + 0.2) / 0.8) * 100 * 0.4);
  const sRisk = Math.round(clamp(1 - dd / 30) * 100 * 0.6 + clamp(rf / 3) * 100 * 0.4);
  const sDisc = Math.round(slPct * 0.5 + clamp(1 - cv) * 100 * 0.3 + (martFlag ? 0 : 100) * 0.2);
  const sRes = Math.round(clamp(1 - (Math.max(maxStreak, 1) - 1) / 9) * 100 * 0.6 + clamp(rf / 3) * 100 * 0.4);
  const mk2 = (key, name, short, score, meta, desc, tip) => ({ key, name, short, score, meta, desc, tip: Array.isArray(tip) ? tip[bandOf(score)] : tip, band: bandOf(score) });
  const dims = [
    mk2(
      "konsistensi",
      "Konsistensi",
      "Konsistensi",
      sKons,
      `${mWin}/${mKeys.length} bulan profit \xB7 ${s.dayKeys.length ? Math.round(dWin / s.dayKeys.length * 100) : 0}% hari profit`,
      "Seberapa teratur profit datang \u2014 dihitung dari persentase bulan dan hari yang berakhir profit.",
      ["Konsistensi bagus \u2014 profit datang secara teratur. Pertahankan target harian yang realistis dan jangan memaksa trade di hari yang sudah profit.", "Kejar keteraturan, bukan jackpot. Tetapkan target harian yang realistis dan berhenti setelah tercapai; satu hari rugi besar bisa menghapus akumulasi berhari-hari.", "Hasil masih naik-turun. Kejar keteraturan, bukan jackpot; fokus pada setup berkualitas dan batasi jumlah trade per hari."]
    ),
    mk2(
      "profit",
      "Profitabilitas",
      "Profit",
      sProf,
      `Profit Factor ${s.profitFactor === Infinity ? "\u221E" : s.profitFactor.toFixed(2)} \xB7 ekspektasi ${s.expectancyR > 0 ? "+" : ""}${s.expectancyR.toFixed(2)}R/trade`,
      "Kualitas cuan \u2014 dari Profit Factor (total profit \xF7 total rugi) dan ekspektasi rata-rata per trade.",
      ["Profit Factor sehat. Jaga disiplin rasio risk:reward dan jangan menahan posisi rugi melewati batas.", "Profit Factor cukup. Tingkatkan rasio risk:reward (minimal 1:1.5) dan potong posisi rugi lebih cepat.", "Profit Factor rendah \u2014 rugi lebih besar dari untung. Perbaiki rasio risk:reward dan evaluasi setup yang paling sering gagal."]
    ),
    mk2(
      "risiko",
      "Manajemen Risiko",
      "Risiko",
      sRisk,
      `Max drawdown ${dd.toFixed(1)}% \xB7 recovery ${rf.toFixed(1)}\xD7`,
      "Ketahanan modal \u2014 dari max drawdown (penurunan terdalam) dan recovery factor (profit \xF7 drawdown).",
      ["Drawdown terkendali. Pertahankan risiko kecil per trade agar kurva ekuitas tetap halus.", "Drawdown mulai terasa. Turunkan risiko per trade ke 1\u20132% modal agar modal tak cepat tergerus.", `Drawdown ${dd.toFixed(1)}% tergolong dalam. Kecilkan risiko per trade ke 1\u20132% modal saja agar kurva ekuitas lebih halus dan modal tak cepat tergerus saat rentetan rugi.`]
    ),
    mk2(
      "disiplin",
      "Disiplin",
      "Disiplin",
      sDisc,
      `Lot ${cv < 0.25 ? "Stabil" : "Agresif"} \xB7 SL dipakai di ${slPct.toFixed(0)}% trade${martFlag ? " \xB7 terdeteksi martingale" : ""}`,
      "Kepatuhan pada aturan \u2014 dari kestabilan ukuran lot dan pemakaian Stop Loss.",
      [slPct < 80 ? `Hanya ${slPct.toFixed(0)}% trade memakai Stop Loss \u2014 ini titik lemah terbesar. Pasang SL di SETIAP posisi supaya satu trade tak pernah bisa menghabiskan akun.` : "", martFlag ? "Hentikan pula kebiasaan menaikkan lot setelah rugi (martingale); tetapkan lot yang tetap." : cv >= 0.25 ? "Ukuran lot masih berubah-ubah; tetapkan lot yang tetap." : ""].filter(Boolean).join(" ") || "Disiplin sudah baik \u2014 pertahankan lot yang stabil dan SL di setiap posisi."
    ),
    mk2(
      "ketahanan",
      "Ketahanan",
      "Ketahanan",
      sRes,
      `Rugi beruntun maks ${maxStreak}\xD7 \xB7 recovery ${rf.toFixed(1)}\xD7`,
      "Kemampuan bangkit dari tekanan \u2014 dari rentetan rugi beruntun terpanjang dan recovery factor.",
      ["Sangat tahan banting. Rentetan rugi pendek dan cepat pulih \u2014 pertahankan dengan SL dan risiko per trade yang kecil.", "Cukup tahan banting. Rentetan rugi terkendali \u2014 jaga agar tetap begitu dengan SL dan risiko per trade yang kecil.", `Rentetan rugi sampai ${maxStreak}\xD7 terlalu panjang. Berhenti sejenak setelah 3 rugi beruntun dan kecilkan lot sampai performa pulih.`]
    )
  ];
  const overall = Math.round(dims.reduce((a, d2) => a + d2.score, 0) / 5);
  const strongest = dims.reduce((a, b) => b.score > a.score ? b : a);
  const weakest = dims.reduce((a, b) => b.score < a.score ? b : a);
  return { ready: n2 >= 3, dims, overall, grade: gradeOf(overall), strongest, weakest };
}

// src/domain/csv.ts
var esc = (v) => {
  const s = String(v ?? "");
  const safe = /^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s) ? `'${s}` : s;
  return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};
var CSV_HEADER = ["Tanggal Entry", "Tanggal Close", "Symbol", "Arah", "Status", "Entry", "Exit", "Lots", "SL", "TP", "Exit Method", "PnL", "Fees", "Setup", "Review"];
function tradesToCsv(trades2) {
  const rows = trades2.map((t) => [
    t.openedAt,
    t.closedAt ?? "",
    t.symbol,
    t.side,
    t.status,
    t.entry,
    t.exit ?? "",
    t.lots,
    t.sl ?? "",
    t.tp ?? "",
    t.exitMethod,
    t.pnl,
    t.fees,
    t.setup,
    t.review
  ].map(esc).join(","));
  return [CSV_HEADER.join(","), ...rows].join("\n");
}

// tests/unit/fixtures.ts
var n = 0;
function mk(o) {
  const t = {
    id: `t${++n}`,
    symbol: "XAUUSD",
    side: "Long",
    closedAt: null,
    entry: 2700,
    lots: 0.1,
    sl: null,
    tp: null,
    fees: 0,
    pnl: 0,
    status: o.exit === null ? "open" : "closed",
    exitMethod: "",
    setup: "",
    review: "",
    attachmentIds: [],
    updatedAt: "2026-10-01T00:00:00+07:00",
    ...o
  };
  if (t.status === "closed") {
    t.closedAt = t.closedAt ?? t.openedAt;
    t.pnl = o.pnl ?? pnlFor(t, t.exit);
  }
  return t;
}
function account(trades2, extra = {}) {
  return { id: "a", name: "Test", currency: "USD", balance: 1e4, firstDeposit: "2026-01-01", trades: trades2, capital: [], ...extra };
}

// tests/unit/stats.test.ts
var trades = [
  mk({ openedAt: "2026-10-01T09:00:00+07:00", closedAt: "2026-10-01T10:00:00+07:00", exit: 1, pnl: 100, sl: 2690, tp: 2720 }),
  mk({ openedAt: "2026-10-02T09:00:00+07:00", closedAt: "2026-10-02T09:30:00+07:00", exit: 1, pnl: -50 }),
  mk({ openedAt: "2026-10-03T15:00:00+07:00", closedAt: "2026-10-03T17:00:00+07:00", exit: 1, pnl: 100, side: "Short" }),
  mk({ openedAt: "2026-10-04T09:00:00+07:00", closedAt: "2026-10-04T09:10:00+07:00", exit: 1, pnl: -50 }),
  mk({ openedAt: "2026-10-05T09:00:00+07:00", closedAt: "2026-10-05T09:10:00+07:00", exit: 1, pnl: -50 }),
  mk({ openedAt: "2026-10-06T21:00:00+07:00", closedAt: "2026-10-06T23:00:00+07:00", exit: 1, pnl: 200 }),
  mk({ openedAt: "2026-10-07T09:00:00+07:00", exit: null })
];
var acc = account(trades);
describe("statistik", () => {
  const s = computeStats(acc, trades);
  it("hitungan dasar", () => {
    expect(s.n).toBe(6);
    expect(s.total).toBe(250);
    expect(s.grossWin).toBe(400);
    expect(s.grossLoss).toBe(150);
    expect(s.profitFactor).toBeCloseTo(400 / 150, 5);
    expect(s.winRate).toBeCloseTo(50, 5);
  });
  it("drawdown dari ekuitas puncak", () => {
    expect(s.maxDrawdown).toBe(100);
    expect(s.highWater).toBe(250);
  });
  it("streak", () => {
    expect(s.maxLossStreak).toBe(2);
    expect(s.maxWinStreak).toBe(1);
  });
  it("trade open tidak ikut", () => {
    expect(s.longs.length + s.shorts.length).toBe(6);
  });
  it("31 baris Advanced Statistics (recon menulis 30; yang benar 31)", () => {
    const rows = advancedRows(acc, s, { y: 2026, m: 9 });
    expect(rows).toHaveLength(31);
    expect(rows[0]).toEqual(["Total Trades", "6", ""]);
    expect(rows.find((r) => r[0] === "Profit Factor")[1]).toBe("2.67");
    expect(rows.find((r) => r[0] === "Profit Pips Okt")).toBeTruthy();
    expect(rows.find((r) => r[0] === "Max Drawdown")[1]).toBe("-$100 \xB7 -1.00%");
  });
  it("rows kosong tidak NaN", () => {
    const e = computeStats(account([]), []);
    const rows = advancedRows(account([]), e, { y: 2026, m: 0 });
    expect(rows.every((r) => !r[1].includes("NaN"))).toBeTruthy();
  });
});
describe("akun", () => {
  it("modal awal & saldo sekarang", () => {
    const a = account(trades, { capital: [{ id: "c1", type: "deposit", amount: 500, date: "2026-10-01", note: "" }, { id: "c2", type: "withdraw", amount: 100, date: "2026-10-02", note: "" }] });
    expect(startingBalance(a)).toBe(9600);
    expect(currentBalance(a)).toBe(10250);
    expect(startingBalance(account([], { balance: 0 }))).toBe(1);
  });
});
describe("DNA", () => {
  it("lima dimensi, skor 0-100, grade valid", () => {
    const s = computeStats(acc, trades);
    const d2 = computeDna(s, trades.filter((t) => t.status === "closed"));
    expect(d2.dims).toHaveLength(5);
    for (const x of d2.dims) {
      expect(x.score).toBeGreaterThan(-1);
      expect(x.score).toBeLessThan(101);
    }
    expect(["A", "B", "C", "D", "E"]).toContain(d2.grade);
    expect(d2.ready).toBeTruthy();
  });
  it("batas grade", () => {
    expect(gradeOf(85)).toBe("A");
    expect(gradeOf(84)).toBe("B");
    expect(gradeOf(70)).toBe("B");
    expect(gradeOf(55)).toBe("C");
    expect(gradeOf(40)).toBe("D");
    expect(gradeOf(39)).toBe("E");
  });
});
describe("periode", () => {
  it("memakai tanggal close", () => {
    const t = mk({ openedAt: "2026-09-30T22:00:00+07:00", closedAt: "2026-10-01T02:00:00+07:00", exit: 1, pnl: 1 });
    const now = Date.parse("2026-10-15T00:00:00+07:00");
    expect(inPeriod(t, { period: "Monthly", now })).toBeTruthy();
    expect(inPeriod(t, { period: "Custom date range", start: "2026-10-01", end: "2026-10-01" })).toBeTruthy();
    expect(inPeriod(t, { period: "Custom date range", start: "2026-09-30", end: "2026-09-30" })).toBeFalsy();
  });
});
describe("CSV", () => {
  it("menetralkan rumus dan mengutip koma", () => {
    const t = mk({ openedAt: "2026-10-01T09:00:00+07:00", exit: null, setup: '=HYPERLINK("x")', review: "a, b" });
    const csv = tradesToCsv([t]);
    expect(csv).toContain(`"'=HYPERLINK(""x"")"`);
    expect(csv).toContain('"a, b"');
  });
});
