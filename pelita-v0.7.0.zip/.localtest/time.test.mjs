// scripts/vitest-shim.ts
import { describe as d, it as i } from "node:test";
import assert from "node:assert/strict";
var describe = d;
var it = i;
var close = (a, b, digits = 2) => Math.abs(a - b) < Math.pow(10, -digits) / 2;
function expect(actual) {
  const mk = (neg) => {
    const chk = (ok, msg) => {
      if (neg ? ok : !ok) assert.fail((neg ? "NOT " : "") + msg);
    };
    return {
      toBe: (e) => chk(Object.is(actual, e), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(e)}`),
      toEqual: (e) => {
        try {
          assert.deepStrictEqual(actual, e);
          chk(true, "");
        } catch (err) {
          if (neg) return;
          throw err;
        }
        if (neg) assert.fail("expected not equal");
      },
      toBeCloseTo: (e, dg = 2) => chk(close(actual, e, dg), `expected ${actual} close to ${e}`),
      toBeTruthy: () => chk(!!actual, `expected truthy, got ${actual}`),
      toBeFalsy: () => chk(!actual, `expected falsy, got ${actual}`),
      toBeNull: () => chk(actual === null, `expected null, got ${actual}`),
      toBeGreaterThan: (e) => chk(actual > e, `expected ${actual} > ${e}`),
      toBeLessThan: (e) => chk(actual < e, `expected ${actual} < ${e}`),
      toHaveLength: (n) => chk(actual.length === n, `expected length ${n}, got ${actual.length}`),
      toContain: (e) => chk(actual.includes(e), `expected ${JSON.stringify(actual)} to contain ${e}`),
      toThrow: () => {
        let t = false;
        try {
          actual();
        } catch {
          t = true;
        }
        chk(t, "expected throw");
      }
    };
  };
  return { ...mk(false), not: mk(true) };
}

// src/domain/time.ts
var WIB_OFFSET_MIN = 7 * 60;
var MS_MIN = 6e4;
var p2 = (n) => String(n).padStart(2, "0");
function toMs(v) {
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v;
  const s = v.trim();
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(s)) {
    const ms = Date.parse(s);
    if (!Number.isNaN(ms)) return ms;
  }
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return Number.NaN;
  const [, y, mo, d2, h = "0", mi = "0", se = "0"] = m;
  return Date.UTC(+y, +mo - 1, +d2, +h, +mi, +se) - WIB_OFFSET_MIN * MS_MIN;
}
function wibParts(v) {
  const shifted = new Date(toMs(v) + WIB_OFFSET_MIN * MS_MIN);
  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  return {
    year,
    month,
    day,
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
    dayKey: `${year}-${p2(month)}-${p2(day)}`,
    monthKey: `${year}-${p2(month)}`
  };
}
function toWibIso(v) {
  const w = wibParts(v);
  return `${w.dayKey}T${p2(w.hour)}:${p2(w.minute)}:00+07:00`;
}
function toInputValue(v) {
  const w = wibParts(v);
  return `${w.dayKey}T${p2(w.hour)}:${p2(w.minute)}`;
}
function tradingDayKey(v) {
  return wibParts(toMs(v) - 7 * 60 * MS_MIN).dayKey;
}
var SESSIONS = [
  { name: "Asia", label: "Asia", hours: "07:00\u201314:00", test: (h) => h >= 7 && h < 14 },
  { name: "London", label: "London", hours: "14:00\u201320:00", test: (h) => h >= 14 && h < 20 },
  { name: "New York", label: "New York", hours: "20:00\u201304:00", test: (h) => h >= 20 || h < 4 },
  { name: "Overlap", label: "Overlap", hours: "04:00\u201307:00", test: (h) => h >= 4 && h < 7 }
];
function sessionOfHour(hour) {
  return (SESSIONS.find((s) => s.test(hour)) ?? SESSIONS[3]).name;
}
var sessionOf = (v) => sessionOfHour(wibParts(v).hour);
function sessionOf3(v) {
  const s = sessionOf(v);
  return s === "Overlap" ? "New York" : s;
}
function weekStartKey(dayKey) {
  const ms = Date.UTC(+dayKey.slice(0, 4), +dayKey.slice(5, 7) - 1, +dayKey.slice(8, 10));
  const wd = (new Date(ms).getUTCDay() + 6) % 7;
  const d2 = new Date(ms - wd * 864e5);
  return `${d2.getUTCFullYear()}-${p2(d2.getUTCMonth() + 1)}-${p2(d2.getUTCDate())}`;
}
function holdMinutes(openedAt, closedAt) {
  if (!closedAt) return null;
  const d2 = (toMs(closedAt) - toMs(openedAt)) / MS_MIN;
  return Number.isFinite(d2) && d2 >= 0 ? d2 : null;
}

// tests/unit/time.test.ts
describe("waktu WIB", () => {
  it("ISO tanpa offset dianggap WIB", () => {
    expect(toWibIso("2026-10-20T09:20")).toBe("2026-10-20T09:20:00+07:00");
  });
  it("UTC dikonversi ke WIB dan melewati tengah malam", () => {
    expect(toWibIso("2026-10-20T20:30:00Z")).toBe("2026-10-21T03:30:00+07:00");
    expect(wibParts("2026-10-20T20:30:00Z").dayKey).toBe("2026-10-21");
  });
  it("offset lain dihormati", () => {
    expect(toMs("2026-10-20T09:20:00+07:00")).toBe(toMs("2026-10-20T02:20:00Z"));
  });
  it("toInputValue", () => {
    expect(toInputValue("2026-10-20T02:20:00Z")).toBe("2026-10-20T09:20");
  });
  it("sesi sesuai definisi baru (07-14, 14-20, 20-04, 04-07)", () => {
    const t = [[7, "Asia"], [13, "Asia"], [14, "London"], [19, "London"], [20, "New York"], [23, "New York"], [0, "New York"], [3, "New York"], [4, "Overlap"], [6, "Overlap"]];
    for (const [h, s] of t) expect(sessionOfHour(h)).toBe(s);
    for (let h = 0; h < 24; h++) expect(["Asia", "London", "New York", "Overlap"]).toContain(sessionOfHour(h));
  });
  it("sesi dari timestamp & 3 sesi", () => {
    expect(sessionOf("2026-10-20T05:00:00+07:00")).toBe("Overlap");
    expect(sessionOf3("2026-10-20T05:00:00+07:00")).toBe("New York");
    expect(sessionOf3("2026-10-20T15:00:00+07:00")).toBe("London");
  });
  it("hari trading mulai 07:00 WIB", () => {
    expect(tradingDayKey("2026-10-20T06:59:00+07:00")).toBe("2026-10-19");
    expect(tradingDayKey("2026-10-20T07:00:00+07:00")).toBe("2026-10-20");
  });
  it("awal minggu = Senin", () => {
    expect(weekStartKey("2026-11-14")).toBe("2026-11-09");
    expect(weekStartKey("2026-11-09")).toBe("2026-11-09");
    expect(weekStartKey("2026-11-15")).toBe("2026-11-09");
  });
  it("lama tahan", () => {
    expect(holdMinutes("2026-10-20T09:00:00+07:00", "2026-10-20T10:30:00+07:00")).toBe(90);
    expect(holdMinutes("2026-10-20T09:00:00+07:00", null)).toBeNull();
    expect(holdMinutes("2026-10-20T10:00:00+07:00", "2026-10-20T09:00:00+07:00")).toBeNull();
  });
});
