// scripts/vitest-shim.ts
import { describe as d, it as i } from "node:test";
import assert from "node:assert/strict";
var describe = d;
var it = i;
var close = (a, b, digits = 2) => Math.abs(a - b) < Math.pow(10, -digits) / 2;
function expect(actual) {
  const mk = (neg) => {
    const chk = (ok, msg) => {
      if (neg ? ok : !ok) assert.fail((neg ? "NOT " : "") + msg);
    };
    return {
      toBe: (e) => chk(Object.is(actual, e), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(e)}`),
      toEqual: (e) => {
        try {
          assert.deepStrictEqual(actual, e);
          chk(true, "");
        } catch (err) {
          if (neg) return;
          throw err;
        }
        if (neg) assert.fail("expected not equal");
      },
      toBeCloseTo: (e, dg = 2) => chk(close(actual, e, dg), `expected ${actual} close to ${e}`),
      toBeTruthy: () => chk(!!actual, `expected truthy, got ${actual}`),
      toBeFalsy: () => chk(!actual, `expected falsy, got ${actual}`),
      toBeNull: () => chk(actual === null, `expected null, got ${actual}`),
      toBeGreaterThan: (e) => chk(actual > e, `expected ${actual} > ${e}`),
      toBeLessThan: (e) => chk(actual < e, `expected ${actual} < ${e}`),
      toHaveLength: (n) => chk(actual.length === n, `expected length ${n}, got ${actual.length}`),
      toContain: (e) => chk(actual.includes(e), `expected ${JSON.stringify(actual)} to contain ${e}`),
      toThrow: () => {
        let t = false;
        try {
          actual();
        } catch {
          t = true;
        }
        chk(t, "expected throw");
      }
    };
  };
  return { ...mk(false), not: mk(true) };
}

// src/domain/time.ts
var WIB_OFFSET_MIN = 7 * 60;
var MS_MIN = 6e4;
var p2 = (n) => String(n).padStart(2, "0");
function toMs(v) {
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v;
  const s = v.trim();
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(s)) {
    const ms = Date.parse(s);
    if (!Number.isNaN(ms)) return ms;
  }
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return Number.NaN;
  const [, y, mo, d2, h = "0", mi = "0", se = "0"] = m;
  return Date.UTC(+y, +mo - 1, +d2, +h, +mi, +se) - WIB_OFFSET_MIN * MS_MIN;
}
function wibParts(v) {
  const shifted = new Date(toMs(v) + WIB_OFFSET_MIN * MS_MIN);
  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  return {
    year,
    month,
    day,
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
    dayKey: `${year}-${p2(month)}-${p2(day)}`,
    monthKey: `${year}-${p2(month)}`
  };
}
function toWibIso(v) {
  const w = wibParts(v);
  return `${w.dayKey}T${p2(w.hour)}:${p2(w.minute)}:00+07:00`;
}

// src/domain/backup.ts
var BACKUP_VERSION = 4;
var CURRENCIES = ["USD", "EUR", "IDR", "GBP"];
var METHODS = ["TP", "SL", "BE", "Manual", ""];
var isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var optNum = (v) => v === "" || v === null || v === void 0 ? null : Number.isFinite(Number(v)) ? Number(v) : NaN;
var str = (v) => typeof v === "string" ? v : "";
function readTrade(raw, acc) {
  if (!isObj(raw)) return null;
  const id = str(raw.id).trim();
  const symbol = str(raw.symbol).trim().toUpperCase();
  const side = raw.side === "Long" || raw.side === "Short" ? raw.side : null;
  const status = raw.status === "open" || raw.status === "closed" ? raw.status : null;
  const entry = Number(raw.entry);
  const lots = Number(raw.lots);
  const exit = optNum(raw.exit), sl = optNum(raw.sl), tp = optNum(raw.tp);
  const fees = optNum(raw.fees) ?? 0;
  const pnl = optNum(raw.pnl) ?? 0;
  const opened = str(raw.openedAt) || str(raw.date);
  if (!id || !symbol || !side || !status || !Number.isFinite(entry) || !(lots > 0)) return null;
  if ([exit, sl, tp, fees, pnl].some((n) => Number.isNaN(n))) return null;
  if (!opened || Number.isNaN(Date.parse(toWibIso(opened)))) return null;
  const closedRaw = str(raw.closedAt) || str(raw.closeDate);
  const closedAt = status === "closed" ? toWibIso(closedRaw || opened) : null;
  const attachmentIds = Array.isArray(raw.attachmentIds) ? raw.attachmentIds.filter((x) => typeof x === "string") : [];
  if (Array.isArray(raw.screenshots)) {
    raw.screenshots.forEach((d2, i2) => {
      if (typeof d2 === "string" && d2.startsWith("data:")) {
        const aid = `${id}-s${i2 + 1}`;
        acc.push({ id: aid, dataUrl: d2 });
        attachmentIds.push(aid);
      }
    });
  }
  return {
    id,
    symbol,
    side,
    status,
    openedAt: toWibIso(opened),
    closedAt,
    entry,
    exit: status === "closed" ? exit : null,
    lots,
    sl,
    tp,
    fees,
    pnl: status === "closed" ? pnl : 0,
    exitMethod: METHODS.includes(raw.exitMethod) ? raw.exitMethod : "",
    setup: str(raw.setup),
    review: str(raw.review),
    attachmentIds,
    mt5Ticket: raw.mt5Ticket ? String(raw.mt5Ticket) : void 0,
    source: raw.source ? String(raw.source) : void 0,
    updatedAt: str(raw.updatedAt) || toWibIso(opened),
    deletedAt: raw.deletedAt ? String(raw.deletedAt) : null
  };
}
function readCapital(raw) {
  const list = Array.isArray(raw) ? raw : [];
  return list.filter(isObj).map((c, i2) => ({
    id: str(c.id) || `cap-${i2 + 1}`,
    type: c.type === "withdraw" ? "withdraw" : "deposit",
    amount: Number(c.amount) || 0,
    date: str(c.date),
    note: str(c.note)
  }));
}
function parseBackup(data) {
  if (!isObj(data) || !Array.isArray(data.accounts) || !data.accounts.length) return null;
  const ids = /* @__PURE__ */ new Set();
  const attachments = [];
  const warnings = [];
  const accounts = [];
  for (const a of data.accounts) {
    if (!isObj(a)) return null;
    const id = str(a.id).trim(), name = str(a.name).trim();
    const currency = CURRENCIES.includes(a.currency) ? a.currency : null;
    const balance = Number(a.balance);
    if (!id || !name || !currency || !Number.isFinite(balance) || !Array.isArray(a.trades) || ids.has(id)) return null;
    ids.add(id);
    const trades = [];
    for (const t of a.trades) {
      const r = readTrade(t, attachments);
      if (!r) return null;
      trades.push(r);
    }
    accounts.push({
      id,
      name,
      currency,
      balance,
      trades,
      firstDeposit: str(a.firstDeposit),
      capital: readCapital(a.capital ?? a.capitalHistory)
    });
  }
  const active = accounts.some((x) => x.id === data.activeAccountId) ? data.activeAccountId : accounts[0].id;
  return { store: { activeAccountId: active, accounts }, attachments, warnings };
}
function makeBackup(store, appVersion, now = (/* @__PURE__ */ new Date()).toISOString()) {
  return { version: BACKUP_VERSION, appVersion, exportedAt: now, activeAccountId: store.activeAccountId, accounts: store.accounts };
}
var previewOf = (s) => ({
  accounts: s.accounts.length,
  trades: s.accounts.reduce((n, a) => n + a.trades.length, 0),
  accountNames: s.accounts.map((a) => a.name)
});

// tests/unit/backup.test.ts
var legacy = {
  version: 3,
  appVersion: "5.9.56",
  activeAccountId: "gold-50",
  accounts: [{
    id: "gold-50",
    name: "Gold 50",
    firstDeposit: "2026-09-01",
    currency: "USD",
    balance: 6049.5,
    capitalHistory: [{ id: "c1", type: "deposit", amount: 100, date: "2026-09-02", note: "" }],
    trades: [
      { id: "t1", symbol: "XAUUSD", side: "Long", date: "2026-10-20T09:20", closeDate: "2026-10-20T10:00", entry: 2728.4, exit: 2735.8, lots: 0.02, sl: 2720, tp: "", pnl: 148, fees: 0, status: "closed", exitMethod: "TP", setup: "x", review: "", screenshots: ["data:image/png;base64,AAAA"] },
      { id: "t5", symbol: "xauusd", side: "Long", date: "2026-10-21T07:45", entry: 2732.1, exit: null, lots: 0.02, sl: 2724, tp: 2745, pnl: 0, fees: 0, status: "open", exitMethod: "", setup: "", review: "" }
    ]
  }]
};
describe("backup & migrasi", () => {
  it("migrasi v3 \u2192 baru: waktu WIB, lampiran dipisah", () => {
    const r = parseBackup(legacy);
    const t = r.store.accounts[0].trades[0];
    expect(t.openedAt).toBe("2026-10-20T09:20:00+07:00");
    expect(t.closedAt).toBe("2026-10-20T10:00:00+07:00");
    expect(t.tp).toBeNull();
    expect(t.attachmentIds).toEqual(["t1-s1"]);
    expect(r.attachments).toHaveLength(1);
    expect(r.store.accounts[0].capital).toHaveLength(1);
    expect(r.store.accounts[0].trades[1].symbol).toBe("XAUUSD");
    expect(r.store.accounts[0].trades[1].closedAt).toBeNull();
  });
  it("trade closed tanpa closeDate memakai waktu buka", () => {
    const l = JSON.parse(JSON.stringify(legacy));
    delete l.accounts[0].trades[0].closeDate;
    expect(parseBackup(l).store.accounts[0].trades[0].closedAt).toBe("2026-10-20T09:20:00+07:00");
  });
  it("menolak data rusak", () => {
    expect(parseBackup(null)).toBeNull();
    expect(parseBackup({ accounts: [] })).toBeNull();
    const l = JSON.parse(JSON.stringify(legacy));
    l.accounts[0].currency = "XXX";
    expect(parseBackup(l)).toBeNull();
    const l2 = JSON.parse(JSON.stringify(legacy));
    l2.accounts[0].trades[0].lots = 0;
    expect(parseBackup(l2)).toBeNull();
    const l3 = JSON.parse(JSON.stringify(legacy));
    l3.accounts.push(l3.accounts[0]);
    expect(parseBackup(l3)).toBeNull();
  });
  it("bolak-balik backup v4 stabil", () => {
    const r1 = parseBackup(legacy);
    const b = makeBackup(r1.store, "0.1.0", "2026-11-14T00:00:00Z");
    const r2 = parseBackup(JSON.parse(JSON.stringify(b)));
    expect(r2.store).toEqual(r1.store);
    expect(previewOf(r2.store).trades).toBe(2);
  });
});
