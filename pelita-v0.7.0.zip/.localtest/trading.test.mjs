// scripts/vitest-shim.ts
import { describe as d, it as i } from "node:test";
import assert from "node:assert/strict";
var describe = d;
var it = i;
var close = (a, b, digits = 2) => Math.abs(a - b) < Math.pow(10, -digits) / 2;
function expect(actual) {
  const mk = (neg) => {
    const chk = (ok, msg) => {
      if (neg ? ok : !ok) assert.fail((neg ? "NOT " : "") + msg);
    };
    return {
      toBe: (e) => chk(Object.is(actual, e), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(e)}`),
      toEqual: (e) => {
        try {
          assert.deepStrictEqual(actual, e);
          chk(true, "");
        } catch (err) {
          if (neg) return;
          throw err;
        }
        if (neg) assert.fail("expected not equal");
      },
      toBeCloseTo: (e, dg = 2) => chk(close(actual, e, dg), `expected ${actual} close to ${e}`),
      toBeTruthy: () => chk(!!actual, `expected truthy, got ${actual}`),
      toBeFalsy: () => chk(!actual, `expected falsy, got ${actual}`),
      toBeNull: () => chk(actual === null, `expected null, got ${actual}`),
      toBeGreaterThan: (e) => chk(actual > e, `expected ${actual} > ${e}`),
      toBeLessThan: (e) => chk(actual < e, `expected ${actual} < ${e}`),
      toHaveLength: (n) => chk(actual.length === n, `expected length ${n}, got ${actual.length}`),
      toContain: (e) => chk(actual.includes(e), `expected ${JSON.stringify(actual)} to contain ${e}`),
      toThrow: () => {
        let t = false;
        try {
          actual();
        } catch {
          t = true;
        }
        chk(t, "expected throw");
      }
    };
  };
  return { ...mk(false), not: mk(true) };
}

// src/domain/trading.ts
var CONTRACT_SIZES = {
  XAUUSD: 100,
  GOLD: 100,
  EURUSD: 1e5,
  GBPUSD: 1e5,
  USDJPY: 1e5,
  GBPJPY: 1e5,
  AUDUSD: 1e5,
  USDCAD: 1e5,
  USDCHF: 1e5,
  NAS100: 1,
  BTCUSD: 1
};
var SYMBOLS = Object.keys(CONTRACT_SIZES);
var contractSize = (symbol) => CONTRACT_SIZES[symbol] ?? 1e5;
var num = (v) => v === null || v === void 0 || v === "" ? NaN : Number(v);
var hasNum = (v) => Number.isFinite(num(v));
function pnlFor(t, exit) {
  if (!hasNum(exit)) return 0;
  const diff = t.side === "Long" ? exit - t.entry : t.entry - exit;
  return diff * t.lots * contractSize(t.symbol) - (Number(t.fees) || 0);
}
var riskFor = (entry, sl, lots, symbol) => entry && hasNum(sl) && sl !== 0 && lots ? Math.abs(entry - sl) * lots * contractSize(symbol) : 0;
var rewardFor = (entry, tp, lots, symbol) => entry && hasNum(tp) && tp !== 0 && lots ? Math.abs(tp - entry) * lots * contractSize(symbol) : 0;
function pipSizeOf(symbol) {
  const u = String(symbol || "").toUpperCase();
  if (u.includes("XAU") || u === "GOLD") return 0.1;
  if (u.includes("XAG")) return 0.01;
  if (u.includes("JPY")) return 0.01;
  if (/BTC|ETH|NAS|US30|SPX/.test(u)) return 1;
  return 1e-4;
}
function pipsOf(t) {
  if (t.status !== "closed" || !hasNum(t.exit)) return 0;
  const d2 = t.side === "Long" ? t.exit - t.entry : t.entry - t.exit;
  return d2 / pipSizeOf(t.symbol);
}

// tests/unit/trading.test.ts
var base = { side: "Long", entry: 2728.4, lots: 0.02, symbol: "XAUUSD", fees: 0 };
describe("P&L", () => {
  it("XAUUSD long cocok dengan jurnal lama (+148 untuk contoh t1)", () => {
    expect(pnlFor(base, 2735.8)).toBeCloseTo(14.8, 2);
  });
  it("short membalik arah", () => {
    expect(pnlFor({ ...base, side: "Short" }, 2735.8)).toBeCloseTo(-14.8, 2);
  });
  it("fees dikurangkan", () => {
    expect(pnlFor({ ...base, fees: 1 }, 2735.8)).toBeCloseTo(13.8, 2);
  });
  it("tanpa exit = 0", () => {
    expect(pnlFor(base, null)).toBe(0);
  });
  it("forex 100000", () => {
    expect(pnlFor({ side: "Short", entry: 1.1764, lots: 0.1, symbol: "EURUSD", fees: 0 }, 1.1749)).toBeCloseTo(15, 2);
  });
  it("risk & reward", () => {
    expect(riskFor(2728.4, 2720, 0.02, "XAUUSD")).toBeCloseTo(16.8, 2);
    expect(rewardFor(2728.4, 2745, 0.02, "XAUUSD")).toBeCloseTo(33.2, 2);
    expect(riskFor(2728.4, null, 0.02, "XAUUSD")).toBe(0);
  });
});
describe("pips", () => {
  it("ukuran pip", () => {
    expect(pipSizeOf("XAUUSD")).toBe(0.1);
    expect(pipSizeOf("USDJPY")).toBe(0.01);
    expect(pipSizeOf("BTCUSD")).toBe(1);
    expect(pipSizeOf("NAS100")).toBe(1);
    expect(pipSizeOf("EURUSD")).toBe(1e-4);
  });
  it("pips trade closed", () => {
    expect(pipsOf({ side: "Long", entry: 2728.4, exit: 2735.8, symbol: "XAUUSD", status: "closed" })).toBeCloseTo(74, 5);
    expect(pipsOf({ side: "Short", entry: 1.1764, exit: 1.1749, symbol: "EURUSD", status: "closed" })).toBeCloseTo(15, 5);
    expect(pipsOf({ side: "Long", entry: 1, exit: null, symbol: "EURUSD", status: "open" })).toBe(0);
  });
});
